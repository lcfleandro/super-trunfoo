#ifdef EXCECOES_H
#define EXCECOES_H

#include <stdexcept>

#endif
