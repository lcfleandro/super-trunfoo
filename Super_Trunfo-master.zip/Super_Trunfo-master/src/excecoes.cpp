#include "excecoes.h"
//Funções


